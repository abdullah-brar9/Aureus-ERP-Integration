<?php

return [
    'add'      => 'Add (+)',
    'subtract' => 'Subtract (-)',
    'multiply' => 'Multiply (×)',
    'divide'   => 'Divide (÷)',
];
